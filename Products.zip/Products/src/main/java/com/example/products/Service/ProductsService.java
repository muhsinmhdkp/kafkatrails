package com.example.products.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.products.Repository.ProductsRepository;
import com.example.products.model.Products;
@Service
public class ProductsService {
@Autowired
ProductsRepository productsRepository;

public List<Products> getAll(){
	List<Products>pro=productsRepository.findAll();
	return pro;
}

public Products addProducts(Products products) {
	 return productsRepository.save(products);
}
public Products getbyId(long id) {
	Optional<Products>pro=productsRepository.findById(id);
	if(pro.isPresent()) {
		Products produt=pro.get();
		return produt;
	}
	return null;
}

public void deleteProduts(long id) {
	productsRepository.deleteById(id); 
}

public Products updateProduct(Products product) {
    Optional<Products> optionalProduct = productsRepository.findById(product.getP_id());
    
    if (optionalProduct.isPresent()) {
        Products existingProduct = optionalProduct.get();
        existingProduct.setP_name(product.getP_name());
        existingProduct.setP_price(product.getP_price());
        
        return productsRepository.save(existingProduct);
    } else {
        // Handle the case when the product with the given ID is not found
        // You can throw an exception or return null, depending on your requirements
        return null;
    }
}

}
