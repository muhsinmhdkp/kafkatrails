package com.example.products.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.products.Service.ProductsService;
import com.example.products.model.Products;

@RestController
@RequestMapping("products")
public class ProductsController {

	@Autowired
	ProductsService productsService;
	
	@GetMapping()
	public ResponseEntity<List<?>>  getAll(){
	List <Products>pro =productsService.getAll();
	return ResponseEntity.ok().body(pro);
	}
	
	@PostMapping("/add")
	public ResponseEntity<?> addProducts(@RequestBody Products produts){
	productsService.addProducts(produts);
	return ResponseEntity.ok().build();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> getById(@PathVariable long id) {
	    Products product = productsService.getbyId(id);
	    if (product != null) {
	        return ResponseEntity.ok().body(product);
	    } else {
	        return ResponseEntity.notFound().build();
	    }
	}

	
	@PutMapping("{id}")
	public ResponseEntity<?> updateProducts(@RequestBody Products produts){
		productsService.updateProduct(produts);
		return ResponseEntity.ok().build();
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteProduts(@PathVariable long id){
	productsService.deleteProduts(id);
	return ResponseEntity.ok().build();
	}
	
}
